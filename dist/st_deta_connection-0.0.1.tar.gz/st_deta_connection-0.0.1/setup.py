from setuptools import setup, find_packages

setup(
    name='st_deta_connection',
    version='0.0.1',
    packages=find_packages(),
    install_requires=[
        'deta<=1.2.0',
        'streamlit<=1.29.0',
        'streamlit-option-menu<=0.3.6',
    ]
)